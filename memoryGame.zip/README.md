memoryGame:
this game let you pick 2 different pictures if the same will steel open if not will colose . we have 16 different pictures so mean there are 8 pictures is similar .
the game has a movement counter if you have less than 14 moves you will get 3 stars if more than 14 moves you will get 2 stars if more than 17 you will get one star.
Gwtting Started:
u click on a MemoryGame.html file then the game will open on your web browser
Prerequisites:
you need web browser 
the function i use is 1 :
shuffle(): will let the array be randome.
newBoard(): creat new borard in the game .
flipThePicture(): flip the picture .
flipBack(): flip the picture back .
restart : restart the game .
win : pop window when you win.


